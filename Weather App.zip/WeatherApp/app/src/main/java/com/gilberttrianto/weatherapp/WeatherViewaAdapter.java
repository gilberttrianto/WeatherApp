package com.gilberttrianto.weatherapp;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class WeatherViewAdapter extends RecyclerView.Adapter<WeatherViewAdapter.ViewHolder> {
    private ArrayList<WeatherItems> mData = new ArrayList<>();

    public WeatherViewAdapter() {

    }

    public void setData(ArrayList<WeatherItems> items) {
        mData.clear();
        mData.addAll(items);
        notifyDataSetChanged();
    }

    public void addItem(WeatherItems item) {
        mData.add(item);
        notifyDataSetChanged();
    }

    public void clearData () {
        mData.clear();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weather,parent,false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.tvNamaKota.setText(mData.get(position).getName());
        holder.tvSuhu.setText(mData.get(position).getTemperature());
        holder.tvDeskripsi.setText(mData.get(position).getDescription());
    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView tvNamaKota, tvSuhu, tvDeskripsi;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tvNamaKota =  itemView.findViewById(R.id.tv_kota);
            tvSuhu = itemView.findViewById(R.id.tv_temp);
            tvDeskripsi = itemView.findViewById(R.id.tv_deskripsi);
        }
    }
}
